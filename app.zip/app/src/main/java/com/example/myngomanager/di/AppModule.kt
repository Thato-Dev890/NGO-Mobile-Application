package com.example.myngomanager.di

import com.example.myngomanager.data.repository.NgoRepository
import com.example.myngomanager.data.repository.NgoRepositoryImpl
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// Hilt Module to provide dependencies

@Module
@InstallIn(SingletonComponent::class)
object AppModule {


    // telling Hilt how to build the repository

    @Provides
    @Singleton
    fun provideNgoRepository(
        auth: FirebaseAuth,
        db: FirebaseFirestore
    ): NgoRepository {
        // When a ViewModel asks for "NgoRepository" (the interface),
        // Hilt will provide "NgoRepositoryImpl" (the implementation).
        return NgoRepositoryImpl(auth, db)
    }
}