package com.example.myngomanager.ui.donor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.myngomanager.databinding.FragmentDonorDonateBinding
import dagger.hilt.android.AndroidEntryPoint

// (class) Fragment for the "Donate" tab
@AndroidEntryPoint
class DonorDonateFragment : Fragment() {

    private var _binding: FragmentDonorDonateBinding? = null
    private val binding get() = _binding!!

    // Get the shared ViewModel
    private val viewModel: DonorViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDonorDonateBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnSubmit.setOnClickListener {
            if (validateForm()) {
                viewModel.submitDonation(
                    amount = binding.etAmount.text.toString().toDouble(),
                    paymentMethod = "Credit Card", // Simplified
                    cardNumber = binding.etCardNumber.text.toString()
                )
            }
        }

        binding.btnMakeAnother.setOnClickListener {
            binding.formLayout.isVisible = true
            binding.successLayout.isVisible = false
            viewModel.resetDonationState()
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.donationSubmitState.observe(viewLifecycleOwner) { state ->
            binding.progressBar.isVisible = state is SubmitState.Loading
            binding.btnSubmit.isEnabled = state !is SubmitState.Loading

            when(state) {
                is SubmitState.Success -> {
                    binding.formLayout.isVisible = false
                    binding.successLayout.isVisible = true
                    clearForm()
                }
                is SubmitState.Error -> {
                    Toast.makeText(context, state.message, Toast.LENGTH_LONG).show()
                }
                else -> {}
            }
        }
    }

    private fun validateForm(): Boolean {
        var isValid = true
        // REQ 1.2: 13-digit card validation
        if (binding.etCardNumber.text.toString().length != 13) {
            binding.tilCardNumber.error = "Must be 13 digits"
            isValid = false
        } else {
            binding.tilCardNumber.error = null
        }

        if (binding.etCvv.text.toString().length != 3) {
            binding.tilCvv.error = "Must be 3 digits"
            isValid = false
        } else {
            binding.tilCvv.error = null
        }

        if (binding.etAmount.text.toString().toDoubleOrNull() == null) {
            binding.tilAmount.error = "Enter a valid amount"
            isValid = false
        } else {
            binding.tilAmount.error = null
        }
        return isValid
    }

    private fun clearForm() {
        binding.etAmount.text?.clear()
        binding.etCardNumber.text?.clear()
        binding.etCvv.text?.clear()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}