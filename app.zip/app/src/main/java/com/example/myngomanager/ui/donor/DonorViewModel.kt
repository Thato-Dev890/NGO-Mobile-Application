package com.example.myngomanager.ui.donor

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.myngomanager.data.model.Donation
import com.example.myngomanager.data.model.User
import com.example.myngomanager.data.repository.NgoRepository
import com.example.myngomanager.util.PdfGenerator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

// The ViewModel for the entire Donor section.
@HiltViewModel
class DonorViewModel @Inject constructor(
    private val repository: NgoRepository
) : ViewModel() {

    private val userId = repository.getCurrentUserId()!!

    // --- Current User State ---
    // We need the user's name for the PDF report
    private val _user = MutableLiveData<User>()

    // --- REQ 1.6: Donation History ---
    val donationHistory: LiveData<List<Donation>> = repository.getMyDonations(userId)
        .map { result -> result.getOrElse { emptyList() } }
        .asLiveData()

    // --- REQ 1.2: Donation Submission ---
    private val _donationSubmitState = MutableLiveData<SubmitState>(SubmitState.Idle)
    val donationSubmitState: LiveData<SubmitState> = _donationSubmitState

    // --- REQ 1.7: PDF Export ---
    private val _pdfExportState = MutableLiveData<Boolean>(false)
    val pdfExportState: LiveData<Boolean> = _pdfExportState

    init {
        viewModelScope.launch {
            repository.getUserRole(userId).onSuccess {
                _user.value = it
            }
        }
    }

    fun submitDonation(amount: Double, paymentMethod: String, cardNumber: String) {
        viewModelScope.launch {
            _donationSubmitState.value = SubmitState.Loading

            val donation = Donation(
                donorId = userId,
                amount = amount,
                paymentMethod = paymentMethod,
                cardNumberMasked = "xxxx-xxxx-${cardNumber.takeLast(4)}"
            )

            val result = repository.createDonation(donation)
            result.fold(
                onSuccess = { _donationSubmitState.value = SubmitState.Success },
                onFailure = { _donationSubmitState.value = SubmitState.Error(it.message ?: "Donation failed") }
            )
        }
    }

    fun resetDonationState() {
        _donationSubmitState.value = SubmitState.Idle
    }

    fun exportHistoryToPdf(context: Context) {
        viewModelScope.launch {
            val history = donationHistory.value
            val user = _user.value

            if (history != null && user != null) {
                _pdfExportState.value = true // Show loading
                val success = PdfGenerator.generateDonationHistory(
                    context = context,
                    donations = history,
                    donorName = user.fullName
                )
                _pdfExportState.value = false // Hide loading
            } else {
                // This line will now work
                Toast.makeText(context, "Data not ready for export", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// Helper sealed class for submission state
sealed class SubmitState {
    data object Idle : SubmitState()
    data object Loading : SubmitState()
    data object Success : SubmitState()
    data class Error(val message: String) : SubmitState()
}