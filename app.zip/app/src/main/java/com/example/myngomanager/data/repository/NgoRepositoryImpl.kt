package com.example.myngomanager.data.repository

import com.example.myngomanager.data.model.Donation
import com.example.myngomanager.data.model.Event
import com.example.myngomanager.data.model.EventSignup
import com.example.myngomanager.data.model.User
import com.example.myngomanager.data.model.UserRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.firestore.ktx.toObjects
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.catch

// This is the implementation of our repository.
// It uses Hilt's @Inject to get the Firebase instances.
class NgoRepositoryImpl @Inject constructor(
    private val auth: FirebaseAuth,
    private val db: FirebaseFirestore
) : NgoRepository {

    // --- Authentication ---
    override fun getCurrentUserId(): String? = auth.currentUser?.uid
    override fun isUserLoggedIn(): Boolean = auth.currentUser != null
    override fun logout() = auth.signOut()

    override suspend fun login(email: String, password: String): Result<Unit> = runSuspendCatching {
        auth.signInWithEmailAndPassword(email, password).await()
    }

    override suspend fun register(
        fullName: String,
        email: String,
        password: String,
        role: UserRole
    ): Result<Unit> = runSuspendCatching {
        val authResult = auth.createUserWithEmailAndPassword(email, password).await()
        val userId = authResult.user?.uid ?: throw IllegalStateException("User ID not found")

        // Create user doc in Firestore (REQ 1.1)
        val user = User(
            uid = userId,
            fullName = fullName,
            email = email,
            role = role
        )
        db.collection("users").document(userId).set(user).await()
    }

    // --- User ---
    override suspend fun getUserRole(userId: String): Result<User> = runSuspendCatching {
        val doc = db.collection("users").document(userId).get().await()
        doc.toObject<User>() ?: throw IllegalStateException("User not found")
    }

    // --- Events (REQ 1.4) ---
    override fun getPublicEvents(): Flow<Result<List<Event>>> = callbackFlow {
        val listener = db.collection("events").orderBy("date", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(Result.failure(error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val events = snapshot.documents.mapNotNull { doc ->
                        doc.toObject<Event>()?.copy(id = doc.id)
                    }
                    trySend(Result.success(events))
                }
            }
        awaitClose { listener.remove() }
    }.catch { emit(Result.failure(it)) }

    override suspend fun createEvent(event: Event): Result<Unit> = runSuspendCatching {
        db.collection("events").add(event).await()
    }

    override suspend fun updateEvent(event: Event): Result<Unit> = runSuspendCatching {
        db.collection("events").document(event.id).set(event).await()
    }

    override suspend fun deleteEvent(eventId: String): Result<Unit> = runSuspendCatching {
        db.collection("events").document(eventId).delete().await()
    }

    // --- Volunteer (REQ 1.3) ---
    override fun getMySignups(volunteerId: String): Flow<Result<List<EventSignup>>> = callbackFlow {
        val listener = db.collection("eventSignups").whereEqualTo("volunteerId", volunteerId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(Result.failure(error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val signups = snapshot.documents.mapNotNull { doc ->
                        doc.toObject<EventSignup>()?.copy(id = doc.id)
                    }
                    trySend(Result.success(signups))
                }
            }
        awaitClose { listener.remove() }
    }.catch { emit(Result.failure(it)) }

    override fun getAvailableEvents(myEventIds: List<String>): Flow<Result<List<Event>>> = callbackFlow {
        val query = if (myEventIds.isEmpty()) {
            db.collection("events").orderBy("date", Query.Direction.ASCENDING)
        } else {
            // This query fetches events *not in* the list of IDs.
            // Note: 'whereNotIn' is limited to 10 items. For more, a different data structure is needed.
            db.collection("events")
                .whereNotIn("id", myEventIds.take(10))
                .orderBy("date", Query.Direction.ASCENDING)
        }

        val listener = query.addSnapshotListener { snapshot, error ->
            // ... (error handling as above) ...
            if (snapshot != null) {
                val events = snapshot.documents.mapNotNull { doc ->
                    doc.toObject<Event>()?.copy(id = doc.id)
                }
                trySend(Result.success(events))
            }
        }
        awaitClose { listener.remove() }
    }.catch { emit(Result.failure(it)) }


    override suspend fun createSignup(signup: EventSignup): Result<Unit> = runSuspendCatching {
        db.collection("eventSignups").add(signup).await()
    }

    override suspend fun deleteSignup(signupId: String): Result<Unit> = runSuspendCatching {
        db.collection("eventSignups").document(signupId).delete().await()
    }

    // --- Donor (REQ 1.2, 1.7) ---
    override suspend fun createDonation(donation: Donation): Result<Unit> = runSuspendCatching {
        db.collection("donations").add(donation).await()
    }

    override fun getMyDonations(donorId: String): Flow<Result<List<Donation>>> = callbackFlow {
        val listener = db.collection("donations").whereEqualTo("donorId", donorId)
            .orderBy("donatedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                // ... (error handling as above) ...
                if (snapshot != null) {
                    val donations = snapshot.toObjects<Donation>()
                    trySend(Result.success(donations))
                }
            }
        awaitClose { listener.remove() }
    }.catch { emit(Result.failure(it)) }

    // --- Admin (REQ 1.5) ---
    override fun getAllDonations(): Flow<Result<List<Donation>>> = callbackFlow {
        val listener = db.collection("donations").addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(Result.failure(error))
                return@addSnapshotListener
            }
            if (snapshot != null) {
                // FIX: Specify the class type here
                val donations = snapshot.toObjects(Donation::class.java)
                trySend(Result.success(donations))
            }
        }
        awaitClose { listener.remove() }
    }.catch { emit(Result.failure(it)) }

    override fun getAllVolunteers(): Flow<Result<List<User>>> = callbackFlow {
        val listener = db.collection("users").whereEqualTo("role", UserRole.VOLUNTEER)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(Result.failure(error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    // FIX: Specify the class type here
                    val users = snapshot.toObjects(User::class.java)
                    trySend(Result.success(users))
                }
            }
        awaitClose { listener.remove() }
    }.catch { emit(Result.failure(it)) }

    override fun getAllSignups(): Flow<Result<List<EventSignup>>> = callbackFlow {
        val listener = db.collection("eventSignups").addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(Result.failure(error))
                return@addSnapshotListener
            }
            if (snapshot != null) {
                // FIX: Specify the class type here
                val signups = snapshot.toObjects(EventSignup::class.java)
                trySend(Result.success(signups))
            }
        }
        awaitClose { listener.remove() }
    }.catch { emit(Result.failure(it)) }
}

// Helper function to wrap suspend calls in a Result
suspend fun <T> runSuspendCatching(block: suspend () -> T): Result<T> {
    return try {
        Result.success(block())
    } catch (e: Exception) {
        Result.failure(e)
    }
}