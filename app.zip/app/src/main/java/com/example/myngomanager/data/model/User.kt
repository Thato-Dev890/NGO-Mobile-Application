package com.example.myngomanager.data.model

// Holds our user data
data class User(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val role: UserRole = UserRole.UNKNOWN
)