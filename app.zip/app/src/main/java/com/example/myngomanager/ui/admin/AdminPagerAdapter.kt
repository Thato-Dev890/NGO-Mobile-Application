package com.example.myngomanager.ui.admin

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

//  Adapter to manage the fragments in the ViewPager
class AdminPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

    override fun getItemCount(): Int = 2 // We have two tabs

    override fun createFragment(position: Int): Fragment {
        // Return the corresponding fragment
        return when (position) {
            0 -> AdminReportsFragment()
            1 -> AdminEventsFragment()
            else -> throw IllegalStateException("Invalid position $position")
        }
    }
}