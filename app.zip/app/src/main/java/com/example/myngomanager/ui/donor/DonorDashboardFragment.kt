package com.example.myngomanager.ui.donor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myngomanager.R
import com.example.myngomanager.databinding.FragmentDonorDashboardBinding
import dagger.hilt.android.AndroidEntryPoint

// (class) This is the main Donor hub with Bottom Navigation.
@AndroidEntryPoint
class DonorDashboardFragment : Fragment() {

    private var _binding: FragmentDonorDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDonorDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the NavHostFragment *within* this fragment's layout
        val navHostFragment = childFragmentManager
            .findFragmentById(R.id.donor_nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        // Link the BottomNavigationView to the inner NavController
        binding.bottomNavigationView.setupWithNavController(navController)

        // Setup logout button
        binding.toolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_logout -> {
                    // TODO: Add logout logic from ViewModel
                    findNavController().navigate(R.id.action_donorDashboardFragment_to_loginFragment)
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}