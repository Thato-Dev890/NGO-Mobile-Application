package com.example.myngomanager.ui.admin

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myngomanager.R
import com.example.myngomanager.databinding.FragmentAdminDashboardBinding
import com.google.android.material.tabs.TabLayoutMediator
import dagger.hilt.android.AndroidEntryPoint

// This is the main Admin hub with ViewPager tabs.
@AndroidEntryPoint
class AdminDashboardFragment : Fragment() {

    private var _binding: FragmentAdminDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminDashboardBinding.inflate(inflater, container, false)

        // Set up the ViewPager adapter
        val pagerAdapter = AdminPagerAdapter(this)
        binding.viewPager.adapter = pagerAdapter

        // Link the TabLayout to the ViewPager
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "Reports"
                1 -> "Events"
                else -> null
            }
        }.attach()

        setupToolbar()

        return binding.root
    }

    private fun setupToolbar() {
        binding.toolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_logout -> {
                    // TODO: Add logout logic from ViewModel
                    findNavController().navigate(R.id.action_adminDashboardFragment_to_loginFragment)
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}