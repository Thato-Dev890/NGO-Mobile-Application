package com.example.myngomanager.ui.donor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myngomanager.data.model.Donation
import com.example.myngomanager.databinding.ItemDonationHistoryBinding
import java.text.SimpleDateFormat
import java.util.Locale

// (class) Adapter for the donation history list
class DonationHistoryAdapter :
    ListAdapter<Donation, DonationHistoryAdapter.DonationViewHolder>(DonationDiffCallback()) {

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DonationViewHolder {
        val binding = ItemDonationHistoryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return DonationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DonationViewHolder, position: Int) {
        val donation = getItem(position)
        holder.bind(donation, dateFormat)
    }

    class DonationViewHolder(private val binding: ItemDonationHistoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(donation: Donation, dateFormat: SimpleDateFormat) {
            binding.tvAmount.text = "R ${"%.2f".format(donation.amount)}"
            binding.tvDate.text = donation.donatedAt?.let { dateFormat.format(it) } ?: "Pending date"
            binding.tvCard.text = "${donation.paymentMethod} (${donation.cardNumberMasked})"
        }
    }

    class DonationDiffCallback : DiffUtil.ItemCallback<Donation>() {
        override fun areItemsTheSame(oldItem: Donation, newItem: Donation): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Donation, newItem: Donation): Boolean = oldItem == newItem    }
}