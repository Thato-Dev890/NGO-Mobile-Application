package com.example.myngomanager.ui.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myngomanager.data.model.User
import com.example.myngomanager.data.repository.NgoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

// A simple state for the Dashboard UI
sealed class DashboardState {
    data object Loading : DashboardState()
    data class RoleLoaded(val user: User) : DashboardState()
    data class Error(val message: String) : DashboardState()
}

// (class) This ViewModel fetches the user's role to decide where to navigate.
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repository: NgoRepository
) : ViewModel() {

    // Internal state to hold the user's data
    private val _userState = MutableLiveData<DashboardState>(DashboardState.Loading)
    // Public LiveData for the Fragment to observe
    val userState: LiveData<DashboardState> = _userState

    init {
        // As soon as the ViewModel is created, fetch the user's role
        loadUserRole()
    }

    private fun loadUserRole() {
        viewModelScope.launch {
            _userState.value = DashboardState.Loading

            val userId = repository.getCurrentUserId()
            if (userId == null) {
                // This case handles if the user is somehow logged out
                _userState.value = DashboardState.Error("User not found. Please log in again.")
                return@launch
            }

            // Get the full User object from the repository
            val result = repository.getUserRole(userId)
            result.fold(
                onSuccess = { user -> _userState.value = DashboardState.RoleLoaded(user) },
                onFailure = { _userState.value = DashboardState.Error(it.message ?: "Failed to get user role") }
            )
        }
    }
}