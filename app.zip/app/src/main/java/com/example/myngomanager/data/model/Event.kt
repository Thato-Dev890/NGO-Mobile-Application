package com.example.myngomanager.data.model

import kotlinx.parcelize.Parcelize
import android.os.Parcelable

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

@Parcelize
data class Event(
    val id: String = "",
    val title: String = "",
    val date: String = "",
    val imageUrl: String = "",
    val description: String = "",
    @ServerTimestamp
    val createdAt: Date? = null
) : Parcelable // 4. Implements this