package com.example.myngomanager.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myngomanager.data.model.UserRole
import com.example.myngomanager.data.repository.NgoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

// A simple sealed class for our UI state
sealed class AuthState {
    data object Idle : AuthState()
    data object Loading : AuthState()
    data object Success : AuthState()
    data class Error(val message: String) : AuthState()
}

//  ViewModel for the Auth screen
@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repository: NgoRepository
) : ViewModel() {

    // Internal state for authentication
    private val _authState = MutableLiveData<AuthState>(AuthState.Idle)
    // Public LiveData for the Fragment to observe
    val authState: LiveData<AuthState> = _authState

    // Check if user is already logged in
    fun isUserLoggedIn(): Boolean {
        return repository.isUserLoggedIn()
    }

    // --- Login Function ---
    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            val result = repository.login(email, password)
            result.fold(
                onSuccess = { _authState.value = AuthState.Success },
                onFailure = { _authState.value = AuthState.Error(it.message ?: "Login failed") }
            )
        }
    }

    // --- Register Function ---
    fun register(fullName: String, email: String, password: String, role: UserRole) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            val result = repository.register(fullName, email, password, role)
            result.fold(
                onSuccess = { _authState.value = AuthState.Success },
                onFailure = { _authState.value = AuthState.Error(it.message ?: "Registration failed") }
            )
        }
    }
}