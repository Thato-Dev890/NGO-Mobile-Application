package com.example.myngomanager.data.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

// Holds signup data
data class EventSignup(
    val id: String = "", // Firestore document ID
    val volunteerId: String = "",
    val volunteerName: String = "",
    val eventId: String = "",
    val eventTitle: String = "",
    val eventDate: String = "",
    @ServerTimestamp
    val signedUpAt: Date? = null
)