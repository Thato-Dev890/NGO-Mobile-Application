package com.example.myngomanager.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.myngomanager.databinding.FragmentAdminReportsBinding
import dagger.hilt.android.AndroidEntryPoint

//  Fragment for the "Reports" tab
@AndroidEntryPoint
class AdminReportsFragment : Fragment() {

    private var _binding: FragmentAdminReportsBinding? = null
    private val binding get() = _binding!!

    // Get the ViewModel that is "scoped" to the parent fragment (AdminDashboardFragment)
    private val viewModel: AdminViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.reportData.observe(viewLifecycleOwner) { data ->
            binding.tvTotalDonations.text = "R ${"%.2f".format(data.totalDonationAmount)}"
            binding.tvTotalVolunteers.text = "${data.totalVolunteerCount}"

            // Build and display text for participation
            binding.tvVolunteerParticipation.text = data.volunteerParticipation.entries
                .joinToString("\n") { "${it.key}: ${it.value} signup(s)" }
                .ifEmpty { "No volunteers have signed up yet." }

            // Build and display text for attendance
            binding.tvEventAttendance.text = data.eventAttendance.entries
                .joinToString("\n") { "${it.key}: ${it.value} signup(s)" }
                .ifEmpty { "No event attendance data available." }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}