package com.example.myngomanager.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf // <-- **NEW IMPORT**
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.myngomanager.R
import com.example.myngomanager.databinding.FragmentAdminEventsBinding
import dagger.hilt.android.AndroidEntryPoint

// (class) Fragment for the "Events" tab
@AndroidEntryPoint
class AdminEventsFragment : Fragment() {

    private var _binding: FragmentAdminEventsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: AdminViewModel by activityViewModels()
    private lateinit var eventAdapter: AdminEventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminEventsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()

        viewModel.eventList.observe(viewLifecycleOwner) { events ->
            eventAdapter.submitList(events)
        }

        // **FIXED (Line 44 area):**
        binding.fabAddEvent.setOnClickListener {
            // We navigate by ID and pass 'null' in a Bundle.
            // The argument "event" must match the name in nav_graph.xml.
            val bundle = bundleOf("event" to null)
            findNavController().navigate(R.id.action_adminDashboardFragment_to_adminEventEditFragment, bundle)
        }
    }

    private fun setupRecyclerView() {
        eventAdapter = AdminEventAdapter(
            onEditClick = { event ->
                // **FIXED (Line 54 area):**
                // We navigate by ID and pass the 'event' object in a Bundle.
                val bundle = bundleOf("event" to event)
                findNavController().navigate(R.id.action_adminDashboardFragment_to_adminEventEditFragment, bundle)
            },
            onDeleteClick = { event ->
                viewModel.deleteEvent(event.id)
            }
        )
        binding.rvEvents.adapter = eventAdapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}