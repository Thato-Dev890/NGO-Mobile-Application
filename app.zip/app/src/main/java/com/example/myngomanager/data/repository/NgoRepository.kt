package com.example.myngomanager.data.repository

import com.example.myngomanager.data.model.Donation
import com.example.myngomanager.data.model.Event
import com.example.myngomanager.data.model.EventSignup
import com.example.myngomanager.data.model.User
import com.example.myngomanager.data.model.UserRole
import kotlinx.coroutines.flow.Flow

// Defines the contract for all app's data operations.
interface NgoRepository {

    // --- Authentication ---
    fun getCurrentUserId(): String?
    fun isUserLoggedIn(): Boolean
    fun logout()
    suspend fun login(email: String, password: String): Result<Unit>
    suspend fun register(fullName: String, email: String, password: String, role: UserRole): Result<Unit>

    // --- User ---
    suspend fun getUserRole(userId: String): Result<User>

    // --- Events (REQ 1.4) ---
    fun getPublicEvents(): Flow<Result<List<Event>>>
    suspend fun createEvent(event: Event): Result<Unit>
    suspend fun updateEvent(event: Event): Result<Unit>
    suspend fun deleteEvent(eventId: String): Result<Unit>

    // --- Volunteer (REQ 1.3) ---
    fun getMySignups(volunteerId: String): Flow<Result<List<EventSignup>>>
    fun getAvailableEvents(myEventIds: List<String>): Flow<Result<List<Event>>>
    suspend fun createSignup(signup: EventSignup): Result<Unit>
    suspend fun deleteSignup(signupId: String): Result<Unit>

    // --- Donor (REQ 1.2, 1.7) ---
    suspend fun createDonation(donation: Donation): Result<Unit>
    fun getMyDonations(donorId: String): Flow<Result<List<Donation>>>

    // --- Admin (REQ 1.5) ---
    fun getAllDonations(): Flow<Result<List<Donation>>>
    fun getAllVolunteers(): Flow<Result<List<User>>>
    fun getAllSignups(): Flow<Result<List<EventSignup>>>
}