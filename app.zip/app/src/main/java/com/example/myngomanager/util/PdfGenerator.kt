package com.example.myngomanager.util

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import com.example.myngomanager.data.model.Donation
import com.itextpdf.text.Document
import com.itextpdf.text.Font
import com.itextpdf.text.PageSize
import com.itextpdf.text.Paragraph
import com.itextpdf.text.pdf.PdfWriter
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// A singleton helper for generating PDF files (REQ 1.7)
object PdfGenerator {

    private val titleFont = Font(Font.FontFamily.TIMES_ROMAN, 18f, Font.BOLD)
    private val bodyFont = Font(Font.FontFamily.TIMES_ROMAN, 12f, Font.NORMAL)
    private val headerFont = Font(Font.FontFamily.TIMES_ROMAN, 12f, Font.BOLD)

    fun generateDonationHistory(
        context: Context,
        donations: List<Donation>,
        donorName: String
    ): Boolean {
        val fileName = "Donation_History_${System.currentTimeMillis()}.pdf"
        var outputStream: OutputStream? = null

        try {
            // Get the output stream
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Modern storage (Android 10+)
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                outputStream = uri?.let { resolver.openOutputStream(it) }
            } else {
                // Older storage
                val path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = java.io.File(path, fileName)
                outputStream = java.io.FileOutputStream(file)
            }

            if (outputStream == null) throw Exception("Failed to create output stream")

            // --- Create PDF Document ---
            val document = Document(PageSize.A4)
            PdfWriter.getInstance(document, outputStream)
            document.open()

            // --- Add Content ---
            document.add(Paragraph("Donation History Report", titleFont))
            document.add(Paragraph("Generated for: $donorName", bodyFont))
            document.add(Paragraph("Date: ${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())}", bodyFont))
            document.add(Paragraph(" ")) // Spacer

            // Table headers
            document.add(Paragraph("Date          Amount          Payment Method          Card", headerFont))
            document.add(Paragraph("---------------------------------------------------------------------------------", bodyFont))

            var totalAmount = 0.0
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

            donations.forEach { donation ->
                val dateStr = donation.donatedAt?.let { dateFormat.format(it) } ?: "N/A"
                val amountStr = "R ${"%.2f".format(donation.amount)}"
                totalAmount += donation.amount

                // Add donation row
                document.add(Paragraph(
                    "${dateStr.padEnd(14)} ${amountStr.padEnd(15)} ${donation.paymentMethod.padEnd(24)} ${donation.cardNumberMasked}",
                    bodyFont
                ))
            }

            // --- Add Total ---
            document.add(Paragraph("---------------------------------------------------------------------------------", bodyFont))
            document.add(Paragraph("Total Donated: R ${"%.2f".format(totalAmount)}", headerFont))

            document.close()
            outputStream.close()

            Toast.makeText(context, "PDF saved to Downloads", Toast.LENGTH_LONG).show()
            return true

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            return false
        } finally {
            outputStream?.flush()
            outputStream?.close()
        }
    }
}