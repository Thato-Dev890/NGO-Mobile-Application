package com.example.myngomanager.ui.volunteer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myngomanager.R
import com.example.myngomanager.databinding.FragmentVolunteerDashboardBinding
import dagger.hilt.android.AndroidEntryPoint

// (class) This is the main Volunteer hub with Bottom Navigation.
@AndroidEntryPoint
class VolunteerDashboardFragment : Fragment() {

    private var _binding: FragmentVolunteerDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentVolunteerDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Find the NavHostFragment *within* this fragment's layout
        val navHostFragment = childFragmentManager
            .findFragmentById(R.id.volunteer_nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        // Link the BottomNavigationView to the inner NavController
        binding.bottomNavigationView.setupWithNavController(navController)

        // Setup logout button
        binding.toolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_logout -> {
                    // TODO: Add logout logic from ViewModel
                    findNavController().navigate(R.id.action_volunteerDashboardFragment_to_loginFragment)
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}