package com.example.myngomanager

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myngomanager.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint // Required for Hilt
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // The NavHostFragment in our layout will handle all navigation
    }
}