package com.example.myngomanager.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.myngomanager.databinding.FragmentAdminEventEditBinding
import dagger.hilt.android.AndroidEntryPoint

// Fragment for the Event Edit/Create form.
@AndroidEntryPoint
class AdminEventEditFragment : Fragment() {

    private var _binding: FragmentAdminEventEditBinding? = null
    private val binding get() = _binding!!

    // Get the ViewModel scoped to the AdminDashboard
    private val viewModel: AdminViewModel by activityViewModels()


    private var eventToEdit: com.example.myngomanager.data.model.Event? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminEventEditBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        // Get the "event" object directly from the arguments bundle.
        eventToEdit = arguments?.getParcelable("event")

        setupUI()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupUI() {
        if (eventToEdit == null) {
            // CREATE mode
            binding.toolbar.title = "Create Event"
        } else {
            // EDIT mode
            binding.toolbar.title = "Edit Event"
            // Pre-fill the form
            binding.etTitle.setText(eventToEdit?.title)
            binding.etDate.setText(eventToEdit?.date)
            binding.etImageUrl.setText(eventToEdit?.imageUrl)
            binding.etDescription.setText(eventToEdit?.description)
        }
    }

    private fun setupClickListeners() {
        // Handle back button
        binding.toolbar.setNavigationOnClickListener {
            findNavController().popBackStack()
        }

        // Handle save button
        binding.btnSave.setOnClickListener {
            val title = binding.etTitle.text.toString()
            val date = binding.etDate.text.toString()
            val imageUrl = binding.etImageUrl.text.toString()
            val description = binding.etDescription.text.toString()

            // Basic form validation
            if (title.isBlank() || date.isBlank()) {
                Toast.makeText(context, "Title and Date are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.saveEvent(title, date, imageUrl, description, eventToEdit)
        }
    }

    private fun observeViewModel() {
        // Observe success
        viewModel.eventOperationSuccess.observe(viewLifecycleOwner) { success ->
            if (success) {
                Toast.makeText(context, "Event Saved!", Toast.LENGTH_SHORT).show()
                viewModel.resetOperationSuccess() // Reset flag
                findNavController().popBackStack() // Go back to event list
            }
        }

        // Observe errors
        viewModel.eventOperationError.observe(viewLifecycleOwner) { error ->
            if (error != null) {
                Toast.makeText(context, error, Toast.LENGTH_LONG).show()
            }
        }


    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}