package com.example.myngomanager.data.model

//  Defines the available user roles
enum class UserRole {
    ADMIN,
    DONOR,
    VOLUNTEER,
    UNKNOWN // For error/loading states
}