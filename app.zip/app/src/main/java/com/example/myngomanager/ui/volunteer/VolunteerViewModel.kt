package com.example.myngomanager.ui.volunteer

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.myngomanager.data.model.Event
import com.example.myngomanager.data.model.EventSignup
import com.example.myngomanager.data.model.User
import com.example.myngomanager.data.repository.NgoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map // <-- **ADD THIS IMPORT**
import kotlinx.coroutines.launch
import javax.inject.Inject

// (class) The ViewModel for the entire Volunteer section.
@HiltViewModel
class VolunteerViewModel @Inject constructor(
    private val repository: NgoRepository
) : ViewModel() {

    private val userId = repository.getCurrentUserId()!!

    // We need the user's name to create a signup
    private val _user = MutableLiveData<User>()

    // A state to manage sign-up or cancellation operations
    private val _operationState = MutableLiveData<VolunteerOpState>(VolunteerOpState.Idle)
    val operationState: LiveData<VolunteerOpState> = _operationState

    // --- Data Flows ---

    // 1. Get the volunteer's personal signups
    private val mySignupsFlow = repository.getMySignups(userId)

    // 2. Get ALL public events
    private val allEventsFlow = repository.getPublicEvents()

    // 3. Combine them to get the list of "My Events" (REQ 1.3)
    val myEvents: LiveData<List<EventSignup>> = mySignupsFlow
        .map { it.getOrElse { emptyList() } } // This line will now work
        .asLiveData()

    // 4. Combine them to get the list of "Available Events" (REQ 1.3)
    val availableEvents: LiveData<List<Event>> = combine(
        allEventsFlow, mySignupsFlow
    ) { allEventsResult, mySignupsResult ->

        val allEventsData = allEventsResult.getOrElse { emptyList() }
        val mySignupsData = mySignupsResult.getOrElse { emptyList() }

        val myEventIds = mySignupsData.map { it.eventId }.toSet()
        // Filter the main list to show only events they haven't joined
        allEventsData.filter { it.id !in myEventIds }
    }.asLiveData()


    init {
        // Fetch the user's details once
        viewModelScope.launch {
            repository.getUserRole(userId).onSuccess {
                _user.value = it
            }
        }
    }

    // --- Actions ---

    fun signUpForEvent(event: Event) {
        viewModelScope.launch {
            _operationState.value = VolunteerOpState.Loading
            val user = _user.value
            if (user == null) {
                _operationState.value = VolunteerOpState.Error("User data not loaded. Cannot sign up.")
                return@launch
            }

            val newSignup = EventSignup(
                volunteerId = user.uid,
                volunteerName = user.fullName,
                eventId = event.id,
                eventTitle = event.title,
                eventDate = event.date
            )

            val result = repository.createSignup(newSignup)
            result.fold(
                onSuccess = { _operationState.value = VolunteerOpState.Success("Signed up!") },
                onFailure = { _operationState.value = VolunteerOpState.Error(it.message ?: "Signup failed") }
            )
        }
    }

    fun cancelSignup(signupId: String) {
        viewModelScope.launch {
            _operationState.value = VolunteerOpState.Loading
            val result = repository.deleteSignup(signupId)
            result.fold(
                onSuccess = { _operationState.value = VolunteerOpState.Success("Signup cancelled.") },
                onFailure = { _operationState.value = VolunteerOpState.Error(it.message ?: "Cancellation failed") }
            )
        }
    }

    fun resetOperationState() {
        _operationState.value = VolunteerOpState.Idle
    }
}

// Helper sealed class for operation state
sealed class VolunteerOpState {
    data object Idle : VolunteerOpState()
    data object Loading : VolunteerOpState()
    data class Success(val message: String) : VolunteerOpState()
    data class Error(val message: String) : VolunteerOpState()
}