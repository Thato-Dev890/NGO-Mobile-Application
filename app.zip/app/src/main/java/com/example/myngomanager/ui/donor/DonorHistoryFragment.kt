package com.example.myngomanager.ui.donor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.myngomanager.databinding.FragmentDonorHistoryBinding
import dagger.hilt.android.AndroidEntryPoint

// (class) Fragment for the "History" tab
@AndroidEntryPoint
class DonorHistoryFragment : Fragment() {

    private var _binding: FragmentDonorHistoryBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DonorViewModel by activityViewModels()
    private lateinit var adapter: DonationHistoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDonorHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()

        binding.btnExportPdf.setOnClickListener {
            viewModel.exportHistoryToPdf(requireContext())
        }

        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = DonationHistoryAdapter()
        binding.rvDonationHistory.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.donationHistory.observe(viewLifecycleOwner) { history ->
            binding.tvEmpty.isVisible = history.isEmpty()
            adapter.submitList(history)
        }

        viewModel.pdfExportState.observe(viewLifecycleOwner) { isLoading ->
            binding.btnExportPdf.isEnabled = !isLoading
            binding.btnExportPdf.text = if (isLoading) "Generating..." else "Export History as PDF"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}