package com.example.myngomanager.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.myngomanager.R
import com.example.myngomanager.data.model.UserRole
import com.example.myngomanager.databinding.FragmentDashboardBinding
import dagger.hilt.android.AndroidEntryPoint

// (class) This Fragment is a "router" that navigates to the
// correct dashboard based on user role.
@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.userState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is DashboardState.Loading -> {
                    // The XML layout is already showing the progress bar
                }
                is DashboardState.RoleLoaded -> {
                    // We got the user! Now, navigate based on role.
                    when (state.user.role) {
                        UserRole.ADMIN -> navigateTo(R.id.action_dashboardFragment_to_adminDashboardFragment)
                        UserRole.DONOR -> navigateTo(R.id.action_dashboardFragment_to_donorDashboardFragment)
                        UserRole.VOLUNTEER -> navigateTo(R.id.action_dashboardFragment_to_volunteerDashboardFragment)
                        UserRole.UNKNOWN -> {
                            // Handle error case, e.g., kick back to login
                            Toast.makeText(context, "Unknown user role. Logging out.", Toast.LENGTH_LONG).show()
                            navigateTo(R.id.action_dashboardFragment_to_loginFragment)
                        }
                    }
                }
                is DashboardState.Error -> {
                    // Show an error and a way to get out
                    Toast.makeText(context, state.message, Toast.LENGTH_LONG).show()
                    navigateTo(R.id.action_dashboardFragment_to_loginFragment)
                }
            }
        }
    }

    private fun navigateTo(actionId: Int) {
        // Use popUpTo to clear this fragment from the back stack
        findNavController().navigate(actionId, null, androidx.navigation.NavOptions.Builder()
            .setPopUpTo(R.id.dashboardFragment, true)
            .build())
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Clear memory
    }
}