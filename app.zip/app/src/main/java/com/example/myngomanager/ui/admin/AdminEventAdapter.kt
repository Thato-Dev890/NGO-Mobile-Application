package com.example.myngomanager.ui.admin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myngomanager.R
import com.example.myngomanager.data.model.Event
import com.example.myngomanager.databinding.ItemAdminEventBinding

// (class) Adapter for the admin event list
class AdminEventAdapter(
    private val onEditClick: (Event) -> Unit,
    private val onDeleteClick: (Event) -> Unit
) : ListAdapter<Event, AdminEventAdapter.EventViewHolder>(EventDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemAdminEventBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = getItem(position)
        holder.bind(event, onEditClick, onDeleteClick)
    }

    class EventViewHolder(private val binding: ItemAdminEventBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(event: Event, onEditClick: (Event) -> Unit, onDeleteClick: (Event) -> Unit) {
            binding.tvEventTitle.text = event.title
            binding.tvEventDate.text = event.date
            binding.ivEventImage.load(event.imageUrl) {
                placeholder(R.drawable.ic_image_placeholder) // Add a placeholder drawable
                error(R.drawable.ic_image_placeholder) // Add an error drawable
            }

            binding.btnEdit.setOnClickListener { onEditClick(event) }
            binding.btnDelete.setOnClickListener { onDeleteClick(event) }
        }
    }

    class EventDiffCallback : DiffUtil.ItemCallback<Event>() {
        override fun areItemsTheSame(oldItem: Event, newItem: Event): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Event, newItem: Event): Boolean = oldItem == newItem
    }
}