package com.example.myngomanager.ui.admin

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.myngomanager.data.model.Donation
import com.example.myngomanager.data.model.Event
import com.example.myngomanager.data.model.EventSignup
import com.example.myngomanager.data.model.User
import com.example.myngomanager.data.repository.NgoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

// Helper data class for the combined report
data class AdminReportData(
    val totalDonationAmount: Double = 0.0,
    val totalVolunteerCount: Int = 0,
    val totalSignups: Int = 0,
    val volunteerParticipation: Map<String, Int> = emptyMap(),
    val eventAttendance: Map<String, Int> = emptyMap()
)

// (class) The ViewModel for the entire Admin section.
@HiltViewModel
class AdminViewModel @Inject constructor(
    private val repository: NgoRepository
) : ViewModel() {

    // --- REQ 1.5: REPORTING ---
    private val _reportData = MutableLiveData<AdminReportData>()
    val reportData: LiveData<AdminReportData> = _reportData

    private val _reportError = MutableLiveData<String?>()
    val reportError: LiveData<String?> = _reportError

    // --- REQ 1.4: EVENT MANAGEMENT ---
    val eventList: LiveData<List<Event>> = repository.getPublicEvents()
        .map { result -> result.getOrElse { emptyList() } } // Convert Flow<Result<List>> to LiveData<List>
        .asLiveData()

    private val _eventOperationError = MutableLiveData<String?>()
    val eventOperationError: LiveData<String?> = _eventOperationError

    private val _eventOperationSuccess = MutableLiveData<Boolean>(false)
    val eventOperationSuccess: LiveData<Boolean> = _eventOperationSuccess

    // --- INIT ---
    init {
        loadAllReportData()
    }

    // --- REPORTING METHODS ---
    fun loadAllReportData() {
        viewModelScope.launch {
            try {

                val donations = repository.getAllDonations().first().getOrElse { emptyList() }
                val volunteers = repository.getAllVolunteers().first().getOrElse { emptyList() }
                val signups = repository.getAllSignups().first().getOrElse { emptyList() }


                _reportData.value = AdminReportData(
                    totalDonationAmount = donations.sumOf { it.amount },
                    totalVolunteerCount = volunteers.size,
                    totalSignups = signups.size,
                    volunteerParticipation = signups.groupingBy { it.volunteerName }.eachCount(),
                    eventAttendance = signups.groupingBy { it.eventTitle }.eachCount()
                )
            } catch (e: Exception) {
                _reportError.value = e.message ?: "Failed to load reports"
            }
        }
    }

    // --- EVENT METHODS ---

    fun saveEvent(
        title: String,
        date: String,
        imageUrl: String,
        description: String,
        eventToEdit: Event?
    ) {
        viewModelScope.launch {
            _eventOperationSuccess.value = false // Reset success flag

            val event = eventToEdit?.copy(
                title = title,
                date = date,
                imageUrl = imageUrl,
                description = description
            ) ?: Event(
                title = title,
                date = date,
                imageUrl = imageUrl,
                description = description
            )

            val result = if (eventToEdit != null) {
                repository.updateEvent(event)
            } else {
                repository.createEvent(event)
            }

            result.fold(
                onSuccess = { _eventOperationSuccess.value = true },
                onFailure = { _eventOperationError.value = it.message ?: "Failed to save event" }
            )
        }
    }

    fun deleteEvent(eventId: String) {
        viewModelScope.launch {
            val result = repository.deleteEvent(eventId)
            result.onFailure {
                _eventOperationError.value = it.message ?: "Failed to delete event"
            }
        }
    }

    // Helper to reset the success flag so we don't navigate twice
    fun resetOperationSuccess() {
        _eventOperationSuccess.value = false
    }
}