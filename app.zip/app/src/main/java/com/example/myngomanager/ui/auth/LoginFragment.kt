package com.example.myngomanager.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.myngomanager.R
import com.example.myngomanager.data.model.UserRole
import com.example.myngomanager.databinding.FragmentLoginBinding
import com.google.android.material.tabs.TabLayout
import dagger.hilt.android.AndroidEntryPoint

// (class) Fragment for the Login/Register screen
@AndroidEntryPoint
class LoginFragment : Fragment() {

    // ViewBinding
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    // Hilt ViewModel
    private val viewModel: AuthViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Check if user is already logged in
        if (viewModel.isUserLoggedIn()) {
            // Navigate to dashboard (we'll add this ID to nav_graph next)
            findNavController().navigate(R.id.action_loginFragment_to_dashboardFragment)
            return
        }

        setupRoleDropdown()
        setupTabs()
        setupSubmitButton()
        observeViewModel()
    }

    private fun setupRoleDropdown() {
        val roles = listOf("Donor", "Volunteer")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, roles)
        binding.autoCompleteRole.setAdapter(adapter)
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab?.position == 0) { // Login
                    binding.tilFullName.isVisible = false
                    binding.tilRole.isVisible = false
                    binding.btnSubmit.text = "Login"
                } else { // Register
                    binding.tilFullName.isVisible = true
                    binding.tilRole.isVisible = true
                    binding.btnSubmit.text = "Register"
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupSubmitButton() {
        binding.btnSubmit.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if (binding.tabLayout.selectedTabPosition == 0) {
                // --- Login ---
                viewModel.login(email, password)
            } else {
                // --- Register ---
                val fullName = binding.etFullName.text.toString()
                val role = if (binding.autoCompleteRole.text.toString() == "Volunteer") {
                    UserRole.VOLUNTEER
                } else {
                    UserRole.DONOR
                }
                viewModel.register(fullName, email, password, role)
            }
        }
    }

    private fun observeViewModel() {
        viewModel.authState.observe(viewLifecycleOwner) { state ->
            // Reset UI
            binding.progressBar.isVisible = false
            binding.btnSubmit.isEnabled = true

            when (state) {
                is AuthState.Loading -> {
                    binding.progressBar.isVisible = true
                    binding.btnSubmit.isEnabled = false
                }
                is AuthState.Success -> {
                    Toast.makeText(context, "Success!", Toast.LENGTH_SHORT).show()
                    // Navigate to dashboard (we'll add this action)
                    findNavController().navigate(R.id.action_loginFragment_to_dashboardFragment)
                }
                is AuthState.Error -> {
                    Toast.makeText(context, state.message, Toast.LENGTH_LONG).show()
                }
                is AuthState.Idle -> {
                    // Do nothing
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Clear memory
    }
}