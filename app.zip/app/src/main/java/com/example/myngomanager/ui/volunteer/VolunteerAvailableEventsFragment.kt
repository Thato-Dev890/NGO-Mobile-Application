package com.example.myngomanager.ui.volunteer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.myngomanager.databinding.FragmentListBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

// (class) Fragment for the "Available Events" tab
@AndroidEntryPoint
class VolunteerAvailableEventsFragment : Fragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!

    private val viewModel: VolunteerViewModel by activityViewModels()
    private lateinit var adapter: VolunteerEventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = VolunteerEventAdapter { event ->
            // Show confirmation dialog
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Sign Up?")
                .setMessage("Confirm your signup for '${event.title}'?")
                .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                .setPositiveButton("Confirm") { _, _ ->
                    viewModel.signUpForEvent(event)
                }
                .show()
        }
        binding.recyclerView.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.availableEvents.observe(viewLifecycleOwner) { events ->
            binding.progressBar.isVisible = events == null
            binding.tvEmpty.isVisible = events?.isEmpty() == true
            adapter.submitList(events)
        }

        viewModel.operationState.observe(viewLifecycleOwner) { state ->
            if (state is VolunteerOpState.Success) {
                Toast.makeText(context, state.message, Toast.LENGTH_SHORT).show()
                viewModel.resetOperationState()
            } else if (state is VolunteerOpState.Error) {
                Toast.makeText(context, state.message, Toast.LENGTH_LONG).show()
                viewModel.resetOperationState()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}