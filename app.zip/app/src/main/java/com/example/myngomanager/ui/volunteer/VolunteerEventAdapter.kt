package com.example.myngomanager.ui.volunteer

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myngomanager.R
import com.example.myngomanager.data.model.Event
import com.example.myngomanager.data.model.EventSignup
import com.example.myngomanager.databinding.ItemVolunteerEventBinding

// (class) Adapter for the "Available Events" list
class VolunteerEventAdapter(
    private val onActionClick: (Event) -> Unit
) : ListAdapter<Event, VolunteerEventAdapter.EventViewHolder>(EventDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemVolunteerEventBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = getItem(position)
        holder.bind(event, "Sign Up", onActionClick)
    }

    class EventViewHolder(private val binding: ItemVolunteerEventBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(event: Event, buttonText: String, onActionClick: (Event) -> Unit) {
            binding.tvEventTitle.text = event.title
            binding.tvEventDate.text = event.date
            binding.tvEventDescription.text = event.description
            binding.btnAction.text = buttonText

            if (event.imageUrl.isBlank()) {
                binding.ivEventImage.isVisible = false
            } else {
                binding.ivEventImage.isVisible = true
                binding.ivEventImage.load(event.imageUrl) {
                    placeholder(R.drawable.ic_image_placeholder)
                    error(R.drawable.ic_image_placeholder)
                }
            }
            binding.btnAction.setOnClickListener { onActionClick(event) }
        }
    }

    class EventDiffCallback : DiffUtil.ItemCallback<Event>() {
        override fun areItemsTheSame(oldItem: Event, newItem: Event): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Event, newItem: Event): Boolean = oldItem == newItem
    }
}

// (class) Adapter for the "My Events" list
class MyEventsAdapter(
    private val onActionClick: (EventSignup) -> Unit
) : ListAdapter<EventSignup, MyEventsAdapter.MyEventViewHolder>(MyEventDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyEventViewHolder {
        val binding = ItemVolunteerEventBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MyEventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyEventViewHolder, position: Int) {
        val signup = getItem(position)
        holder.bind(signup, "Cancel", onActionClick)
    }

    class MyEventViewHolder(private val binding: ItemVolunteerEventBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(signup: EventSignup, buttonText: String, onActionClick: (EventSignup) -> Unit) {
            binding.tvEventTitle.text = signup.eventTitle
            binding.tvEventDate.text = signup.eventDate
            binding.tvEventDescription.text = "You are signed up for this event."
            binding.btnAction.text = buttonText
            binding.ivEventImage.isVisible = false // No image on this card

            binding.btnAction.setOnClickListener { onActionClick(signup) }
        }
    }

    class MyEventDiffCallback : DiffUtil.ItemCallback<EventSignup>() {
        override fun areItemsTheSame(oldItem: EventSignup, newItem: EventSignup): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: EventSignup, newItem: EventSignup): Boolean = oldItem == newItem
    }
}