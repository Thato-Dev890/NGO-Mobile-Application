package com.example.myngomanager

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

// This (class) is the entry point of the app for Hilt
@HiltAndroidApp
class NgoApp : Application() {
    // This class is required for Hilt to work
}