package com.example.myngomanager.data.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

// Holds donation data
data class Donation(
    val id: String = "",
    val donorId: String = "",
    val amount: Double = 0.0,
    val paymentMethod: String = "",
    val cardNumberMasked: String = "",
    @ServerTimestamp
    val donatedAt: Date? = null
)