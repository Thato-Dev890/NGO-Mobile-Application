package com.example.myngomanager.ui.volunteer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.myngomanager.databinding.FragmentListBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint

// (class) Fragment for the "My Events" tab
@AndroidEntryPoint
class VolunteerMyEventsFragment : Fragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!

    private val viewModel: VolunteerViewModel by activityViewModels()
    private lateinit var adapter: MyEventsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = MyEventsAdapter { signup ->
            // Show confirmation dialog
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Cancel Signup?")
                .setMessage("Are you sure you want to cancel '${signup.eventTitle}'?")
                .setNegativeButton("Keep") { dialog, _ -> dialog.dismiss() }
                .setPositiveButton("Confirm") { _, _ ->
                    viewModel.cancelSignup(signup.id)
                }
                .show()
        }
        binding.recyclerView.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.myEvents.observe(viewLifecycleOwner) { events ->
            binding.progressBar.isVisible = events == null
            binding.tvEmpty.isVisible = events?.isEmpty() == true
            binding.tvEmpty.text = "You haven't signed up for any events yet."
            adapter.submitList(events)
        }

        viewModel.operationState.observe(viewLifecycleOwner) { state ->
            if (state is VolunteerOpState.Success) {
                Toast.makeText(context, state.message, Toast.LENGTH_SHORT).show()
                viewModel.resetOperationState()
            } else if (state is VolunteerOpState.Error) {
                Toast.makeText(context, state.message, Toast.LENGTH_LONG).show()
                viewModel.resetOperationState()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}